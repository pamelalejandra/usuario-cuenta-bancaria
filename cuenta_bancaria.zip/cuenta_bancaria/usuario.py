from datetime import datetime

class User:
    def __init__(self, name, email_address):
        self.name = name
        self.email = email_address
        self.account_balance = 0
        self.transaction_history = []
    def make_deposit(self, amount):
        if amount > 0:
            self.account_balance += amount
            self.transaction_history.append({"date": datetime.now(), "type": "Deposito", "amount": amount})
        else:
            print("El monto del deposito debe ser mayor a cero.")
    def bank_draft(self, amount):
        if amount > 0:
            self.account_balance -= amount
            self.transaction_history.append({"date": datetime.now(), "type": "Retiro", "amount": amount})
        else:
            print("El monto del retiro debe ser mayor a cero.")
    def get_balance(self):
        return self.account_balance
    def get_transaction_history(self):
        return self.transaction_history 

users =[User("Alejandra R.", "alejandra@python.com"),
        User("Natalia R.", "natalia@python.com"),
        User("Claudia", "claudia@python.com")]

users [0] = User("Alejandra R.", "alejandra@python.com")
users [0].make_deposit(300)
users [0].make_deposit(100)
users [0].make_deposit(50)
users [0].bank_draft(300)
account_balance = users [0].get_balance()
history = users [0].get_transaction_history()


users [1] = User("Natalia R.", "natalia@python.com")
users [1].make_deposit(500)
users [1].make_deposit(200)
users [1].bank_draft(200)
users [1].bank_draft(200)
account_balance = users [1].get_balance()
history = users [1].get_transaction_history()

users[2] = User("Claudia R.", "claudia@python.com")
users[2].make_deposit(800)
users[2].bank_draft(200)
users[2].bank_draft(500)
users[2].bank_draft(300)
account_balance = users[2].get_balance()
history = users[2].get_transaction_history()

for user in users:
    print(f"Recibirá un comprobante en el mail {user.email}")
    print(f"El balance de la cuenta del usuario {user.name} es: {user.get_balance()}")
    history = user.get_transaction_history()
    for transaction in history:
        print (f"Historial: {transaction['type']}, Monto: {transaction['amount']}")
    print()
